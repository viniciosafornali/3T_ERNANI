//CRIE UM PROGRAMA QUE CHEQUE USUARIO E SENHA
//CASO O USUARIO E SENHA SEJAM IGUAIS AO CADASTRADO, MOSTRE UM MENSAGEM DE SUCESSO
//CASO CONTRARIO, PERGUNTE NOVAMENTE (WHILE)

const usuario = "admin"
const senha = "54321"
let u, s = ''
let estaLogado = false

while (!estaLogado) {
  u = prompt("Digite o usuário: ")
  s = prompt("Digite a senha: ")

  if (u == usuario && s == senha) {
    window.prompt('asseso permitido')
    estaLogado = true
  } else {
    window.promp('Usuário ou senha invalido')
  }
}