//LOOP WHILE (ENQUANTO)
//RODA NUM LOOP INFINITO POR PADÃO
//MAS PODEMOS ESTIPULAR UMA INFORMAÇÃO
//DE ARADA PARA CONTROLÁ-LO
//SINTAXE: WHILE (CONDIÇÃO) {CÓDIGO}
let n = 0;
while (n < 700) {
  // console.clear()
  if (n % 2 == 1) {
    console.log(n);
  }
  n = n + 1;
}
