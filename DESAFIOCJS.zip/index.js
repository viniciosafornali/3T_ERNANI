import { acelerar } from './lib/veiculos.js';

import { mostrarDadosVeiculo } from './lib/veiculos.js';

import {fs} from "./lib/cjs.cjs";

console.log(mostrarDadosVeiculo());

console.log(acelerar());

console.log(fs);
