



//LOOP WHILE É UM CICLO DE REPETIÇÃO QUE PODE SER PARADO ATRAVÉS DE UMA CONDIÇÃO
//O SETINTERVAL É UM CICLO DE REPETIÇÃO QUE EXECUTA UM CÓDIGO TEMPOS EM TEMPOS (INTERVALO EM MILINSEGUNDOS)
// while(true) {
//  console.log('Oi')
// }

const intervalo = setInterval(function () {
  let n = Math.round(Math.random() * 60);
  console.clear();
  console.log(`FPS: ${n}`);
}, 10000);

//clearInterval(intervalo) CONSIGO PARAR