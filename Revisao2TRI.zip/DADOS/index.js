// arrays são indexados
// possuem métodos
// podem ser iterados
const nome = "Otata";
const time = ["Francisco", "Pepe", "Benacosta", "Raimundinho", "cheitom"];
//(PARENTES),[COLCHETES],{CHAVES}
console.log(time);
time.push("Arguntino"); // SEMPRE NO FINAL DA LISTA
time.shift(); // Remova alguém do inicio
console.log(time[2]); // José
console.log(time[20]); // undefined
time[20] = "Bolsonaro";
console.log(time[20]); // Bolsonaro
// ITERAR - LOOP ATÉ ESGOTAMENTO (FOR, FOREACCH, WHILE, FOR IN, FOR OF)
for (var i = 0; i <= 4; i++) {
  console.log(time[i]);
}
