//CRINDO NOSSO SERVIDOR
const express = require("express");
const path = require("path");
const app = express();

const PORT = 4545;

//criar rotas
app.get("/", function (req, res) {
  //nosso código vem aqui
  res.send("Hello");
});

// USANDO O SERVIDOR NUMA DADA PORTA
app.listen(4545, function () {
  console.log("rodando na aporta: " + PORT);
});
