/** CRIE UM ARRAY DE OBJETOS => PESSOAS
 * COM OSA SEGUINTES ATRIBUTOS: NOME/SOBRENOME
 * CRIE UMA FUNCÃO QUE ITERE SOBRE O ARREY
 * E RETIRE NOME E SOBRENOMES
 *     -> const emailBase  = "@escola.pr.gov.br"
 * A PARTIR DESSES DADOS FORME UM @escola com
 * NOME.SOBRENOME+EMAIBASE
 * EXECUTE A FUNÇÃO...
 */
const pessoas = [
  {nome: "João", sobrenome: "Ameida",},
  {nome; "jose", sobrenome: "Silva",},
  {nome: "Ronaldo",sobrenome: "Tokarci",},
]
//CRIE EMAIL BASE

for (pessoa of pessoas))