//OPERADOR TERNÁRIO SERVE PARA DEVIO CONDICIONAL, ASSIM COMO O IF ELSE, POREM SUA SINTASE SIMPLIFICA
//PODEMOS ULTILIZAR O OPERADOR TERNÁRIO ANHINHADO
//EX: <VARIÁVEL> = <CONDIÇÃO> ?  <VALOR_TRUE> : <VALOR_FALSE>

const idade = 18;

const cnh =
  idade >= 18 ? "maiores porem dirigir" : "menor de idade não pode dirigir";
console.log(cnh);

let pessoas = [
  { nome: "vini", sexo: "M", idade: 17 },
  { nome: "vagner", sexo: "M", idade: 18 },
  { nome: "taborda", sexo: "M", idade: 19 },
  { nome: "pedro", sexo: "M", idade: 18 },
];
let meninas = [];
let meninos = [];
for (let nome of pessoas) {
  pessoas.sexo == "F" ? meninas.push(nome) : meninos.push(nome);
}
console.table(meninas);
console.table(meninos);
